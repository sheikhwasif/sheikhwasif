
<?php
 include('config/constant.php');

$name= $_POST["name"];
$email= $_POST["email"];
$comment= $_POST["comments"];



$sql = "INSERT INTO contact (name,email,comment)
VALUES ('$name', '$email', '$comment')";
if (mysqli_query($conn, $sql)) {
echo "WE GOT YOUR QUERRY";
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}


?>
</br>
<html>
<a href="contact.php">Click to get to the previous page</a>
</html>
